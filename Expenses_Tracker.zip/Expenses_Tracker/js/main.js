import BudgetTracker from "./BudgetTracker.js";

new BudgetTracker("#app");